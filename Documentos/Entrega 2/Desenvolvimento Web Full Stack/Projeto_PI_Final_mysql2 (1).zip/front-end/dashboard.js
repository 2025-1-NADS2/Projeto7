
document.addEventListener("DOMContentLoaded", async function () {
  const token = localStorage.getItem("token");
  if (!token) {
    alert("Usuário não autenticado. Redirecionando para login.");
    window.location.href = "login.html";
    return;
  }

  try {
    const response = await fetch("http://localhost:3000/api/items", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    const data = await response.json();

    if (response.ok) {
      const lista = document.getElementById("lista-eventos");
      data.forEach((item) => {
        const div = document.createElement("div");
        div.className = "evento";
        div.innerHTML = `
          <h3>${item.nome}</h3>
          <p>${item.descricao}</p>
          <p>Data: ${item.data}</p>
          <button onclick="editar(${item.id})">Editar</button>
          <button onclick="excluir(${item.id})">Excluir</button>
        `;
        lista.appendChild(div);
      });
    } else {
      alert("Erro ao carregar eventos: " + data.message);
    }
  } catch (error) {
    console.error("Erro:", error);
    alert("Erro ao carregar eventos.");
  }
});

function editar(id) {
  window.location.href = "editar-evento.html?id=" + id;
}

function excluir(id) {
  if (confirm("Tem certeza que deseja excluir este evento?")) {
    const token = localStorage.getItem("token");
    fetch(`http://localhost:3000/api/items/${id}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((res) => res.json())
      .then((res) => {
        alert("Evento excluído com sucesso.");
        location.reload();
      })
      .catch((err) => {
        console.error("Erro:", err);
        alert("Erro ao excluir.");
      });
  }
}