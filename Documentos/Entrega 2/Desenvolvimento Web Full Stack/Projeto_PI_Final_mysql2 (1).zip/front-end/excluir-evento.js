
document.addEventListener("DOMContentLoaded", function () {
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");

  const token = localStorage.getItem("token");
  if (!token) {
    alert("Usuário não autenticado.");
    window.location.href = "login.html";
    return;
  }

  document.getElementById("confirmar-exclusao").addEventListener("click", async function () {
    try {
      const response = await fetch(`http://localhost:3000/api/items/${id}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await response.json();

      if (response.ok) {
        alert("Evento excluído com sucesso.");
        window.location.href = "dashboard.html";
      } else {
        alert("Erro ao excluir: " + data.message);
      }
    } catch (error) {
      console.error("Erro:", error);
      alert("Erro ao excluir.");
    }
  });
});