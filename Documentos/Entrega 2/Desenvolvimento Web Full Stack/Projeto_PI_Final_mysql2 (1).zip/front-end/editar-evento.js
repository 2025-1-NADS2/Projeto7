
document.addEventListener("DOMContentLoaded", async function () {
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");

  const token = localStorage.getItem("token");
  if (!token) {
    alert("Usuário não autenticado.");
    window.location.href = "login.html";
    return;
  }

  // Carregar dados do item
  try {
    const response = await fetch(`http://localhost:3000/api/items/${id}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    const data = await response.json();

    if (response.ok) {
      document.getElementById("nome").value = data.nome;
      document.getElementById("descricao").value = data.descricao;
      document.getElementById("data").value = data.data;
    } else {
      alert("Erro ao carregar item: " + data.message);
    }
  } catch (error) {
    console.error("Erro:", error);
  }

  // Atualizar item
  document.getElementById("editar-form").addEventListener("submit", async function (e) {
    e.preventDefault();
    const nome = document.getElementById("nome").value;
    const descricao = document.getElementById("descricao").value;
    const data = document.getElementById("data").value;

    try {
      const res = await fetch(`http://localhost:3000/api/items/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ nome, descricao, data }),
      });

      const result = await res.json();

      if (res.ok) {
        alert("Evento atualizado com sucesso!");
        window.location.href = "dashboard.html";
      } else {
        alert("Erro: " + result.message);
      }
    } catch (err) {
      console.error("Erro:", err);
      alert("Erro ao atualizar.");
    }
  });
});