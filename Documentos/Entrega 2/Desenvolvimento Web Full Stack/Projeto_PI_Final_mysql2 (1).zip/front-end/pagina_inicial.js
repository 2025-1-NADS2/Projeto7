
document.addEventListener("DOMContentLoaded", async function () {
  try {
    const response = await fetch("http://localhost:3000/api/items");
    const data = await response.json();

    if (response.ok) {
      const lista = document.getElementById("eventos-publicos");
      data.forEach((item) => {
        const div = document.createElement("div");
        div.className = "evento";
        div.innerHTML = `
          <h3>${item.nome}</h3>
          <p>${item.descricao}</p>
          <p>Data: ${item.data}</p>
        `;
        lista.appendChild(div);
      });
    } else {
      alert("Erro ao carregar eventos: " + data.message);
    }
  } catch (error) {
    console.error("Erro:", error);
    alert("Erro ao carregar eventos.");
  }
});