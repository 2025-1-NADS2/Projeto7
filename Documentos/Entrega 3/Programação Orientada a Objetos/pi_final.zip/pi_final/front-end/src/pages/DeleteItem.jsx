import '../assets/excluir-evento.css'

export default function DeleteItem() {
  return (
    <div className="form-container">
      <h1>Excluir Item</h1>
      <form>
        <label>ID do Item:</label>
        <input type="text" placeholder="Digite o ID" />
        <button type="submit">Excluir</button>
      </form>
    </div>
  )
}
