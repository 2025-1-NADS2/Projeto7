
import React from "react";
import "./Card.css";

const Card = ({ title, image, description, children }) => {
  return (
    <div className="card">
      {image && <img src={image} alt={title} className="card-img" />}
      <div className="card-content">
        <h3>{title}</h3>
        <p>{description}</p>
        {children}
      </div>
    </div>
  );
};

export default Card;
