import '../assets/criar-evento.css'

export default function CreateItem() {
  return (
    <div className="form-container">
      <h1>Criar Item</h1>
      <form>
        <label>Título:</label>
        <input type="text" placeholder="Digite o título" />
        <label>Descrição:</label>
        <textarea placeholder="Digite a descrição"></textarea>
        <label>Imagem:</label>
        <input type="file" />
        <button type="submit">Salvar</button>
      </form>
    </div>
  )
}
