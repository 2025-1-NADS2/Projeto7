
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

export default function Form() {
  const [nome, setNome] = useState('')
  const [descricao, setDescricao] = useState('')
  const [imagem, setImagem] = useState(null)
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    const formData = new FormData()
    formData.append('nome', nome)
    formData.append('descricao', descricao)
    if (imagem) formData.append('imagem', imagem)

    try {
      const response = await fetch('http://localhost:3000/items', {
        method: 'POST',
        body: formData
      })
      if (response.ok) {
        alert('Item criado com sucesso!')
        navigate('/dashboard')
      } else {
        alert('Erro ao criar item.')
      }
    } catch (error) {
      console.error('Erro:', error)
      alert('Erro ao conectar com a API.')
    }
  }

  return (
    <div className="p-4 max-w-md mx-auto">
      <h2 className="text-2xl font-bold mb-4">Criar Novo Item</h2>
      <form onSubmit={handleSubmit} className="flex flex-col gap-3">
        <input
          type="text"
          placeholder="Nome"
          value={nome}
          onChange={(e) => setNome(e.target.value)}
          required
          className="border p-2 rounded"
        />
        <textarea
          placeholder="Descrição"
          value={descricao}
          onChange={(e) => setDescricao(e.target.value)}
          required
          className="border p-2 rounded"
        />
        <input
          type="file"
          onChange={(e) => setImagem(e.target.files[0])}
          className="border p-2 rounded"
        />
        <button type="submit" className="bg-blue-600 text-white p-2 rounded hover:bg-blue-700">
          Enviar
        </button>
      </form>
    </div>
  )
}
