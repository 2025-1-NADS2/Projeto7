import './Home.css'
import logo from '../assets/logo.png'

export default function Home() {
  return (
    <div>
      <header>
        <div className="container header-container">
          <div className="logo">
            <img src={logo} alt="Logo" className="corner-logo" />
          </div>
          <button className="mobile-menu-btn" id="mobileMenuBtn">
            <i className="fas fa-bars"></i>
          </button>
          <nav id="mainNav">
            <ul>
              <li><a href="#home">Home</a></li>
              <li><a href="#sobre">Sobre Nós</a></li>
              <li><a href="#segmentos">Nossos Segmentos</a></li>
              <li><a href="#equipe">Equipe</a></li>
            </ul>
          </nav>
        </div>
      </header>
      <main>
        <section id="home">
          <h1>Bem-vindo ao Instituto Criativo</h1>
          <p>Transformando vidas através da educação criativa e inovadora.</p>
        </section>
        <section id="sobre">
          <h2>Sobre Nós</h2>
          <p>Somos uma ONG que acredita na educação como instrumento de transformação.</p>
        </section>
        <section id="segmentos">
          <h2>Nossos Segmentos</h2>
          <p>Educação, Cultura, Tecnologia e Inovação Social.</p>
        </section>
        <section id="equipe">
          <h2>Nossa Equipe</h2>
          <p>Profissionais engajados com a mudança social através do conhecimento.</p>
        </section>
      </main>
    </div>
  )
}
