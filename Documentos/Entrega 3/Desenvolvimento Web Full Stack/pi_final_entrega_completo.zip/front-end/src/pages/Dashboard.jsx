import Card from "../components/Card";

import { useAuth } from '../AuthContext'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'

export default function Dashboard() {
  const { logout, token } = useAuth()
  const [items, setItems] = useState([])
  const [darkMode, setDarkMode] = useState(false)
  const navigate = useNavigate()

  useEffect(() => {
    fetch('http://localhost:3000/items', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    })
      .then(res => res.json())
      .then(data => setItems(data))
      .catch(err => console.error('Erro ao carregar itens:', err))
  }, [token])

  const handleDelete = async (id) => {
    await fetch(`http://localhost:3000/items/${id}`, {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${token}`
      }
    })
    setItems(items.filter(item => item.id !== id))
  }

  const toggleDarkMode = () => {
    setDarkMode(!darkMode)
  }

  return (
    <div className={darkMode ? 'dashboard dark' : 'dashboard'}>
      <header>
        <h1>Dashboard</h1>
        <button onClick={logout}>Sair</button>
        <button onClick={toggleDarkMode}>
          {darkMode ? 'Modo Claro' : 'Modo Escuro'}
        </button>
      </header>
      <section className="item-list">
        {items.map(item => (
          <div key={item.id} className="item-card">
            <h3>{item.nome}</h3>
            <p>{item.descricao}</p>
            <button onClick={() => navigate(`/edit/${item.id}`)}>Editar</button>
            <button onClick={() => handleDelete(item.id)}>Excluir</button>
          </div>
        ))}
      </section>
    </div>
  )
}
