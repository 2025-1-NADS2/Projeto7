import express, { urlencoded } from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
import routes from './routes.js'
import helmet from 'helmet'
import rateLimit from 'express-rate-limit'
import compression from 'compression'

dotenv.config()
const app = express()
const port = process.env.PORT || 3000

app.use(cors({
    origin: '*'
}));
app.use(express.json())

app.use(helmet())
app.use(compression())
app.use(rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutos
    max: 100 // limita cada IP a 100 requisições por janela
}))

app.use(urlencoded({extended: true}))
app.use(express.static('public'))
app.use('/uploads', express.static('uploads'))
app.use("/api", routes)


//Conexão
app.listen(port, ()=> {
    console.log(`Servidor rodando em: http://localhost:${port}`)
})

