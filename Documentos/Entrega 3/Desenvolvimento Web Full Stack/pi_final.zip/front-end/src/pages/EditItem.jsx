import '../assets/editar-evento.css'

export default function EditItem() {
  return (
    <div className="form-container">
      <h1>Editar Item</h1>
      <form>
        <label>Título:</label>
        <input type="text" placeholder="Novo título" />
        <label>Descrição:</label>
        <textarea placeholder="Nova descrição"></textarea>
        <label>Imagem:</label>
        <input type="file" />
        <button type="submit">Atualizar</button>
      </form>
    </div>
  )
}
