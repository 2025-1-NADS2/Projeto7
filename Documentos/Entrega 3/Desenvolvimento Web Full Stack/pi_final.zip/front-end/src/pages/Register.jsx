import '../assets/login.css'

export default function Register() {
  return (
    <div className="login-container">
      <h1>Cadastro</h1>
      <form>
        <label>Nome:</label>
        <input type="text" placeholder="Digite seu nome" />
        <label>Email:</label>
        <input type="email" placeholder="Digite seu email" />
        <label>Senha:</label>
        <input type="password" placeholder="Crie uma senha" />
        <button type="submit">Cadastrar</button>
      </form>
    </div>
  )
}
