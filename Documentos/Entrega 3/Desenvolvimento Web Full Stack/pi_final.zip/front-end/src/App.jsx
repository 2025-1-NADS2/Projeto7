
import { Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import Form from './pages/Form'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import ProtectedRoute from './ProtectedRoute'

import React, { useEffect, useState } from "react";

function App() {
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    document.body.className = darkMode ? "dark" : "";
  }, [darkMode]);

  return (
    <div>
      <header style={{ padding: "1rem" }}>
        <button onClick={() => setDarkMode(!darkMode)}>
          {darkMode ? "Modo Claro" : "Modo Escuro"}
        </button>
      </header>
      {/* Rotas e conteúdo abaixo */}
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/form" element={<Form />} />
      <Route path="/login" element={<Login />} />
      <Route path="/dashboard" element={
        <ProtectedRoute>
          <Dashboard />
        </ProtectedRoute>
      } />
    </Routes>
  )
}

export default App

</div>