const eventos = [
    { nome: "Workshop de Design", data: "15/06/2024", preco: 100 },
    { nome: "Aula de Fotografia", data: "10/07/2024", preco: 80 },
    { nome: "Seminário de Arte", data: "23/08/2024", preco: 120 }
];

const usuarios = {
    total: 120, 
    admin: 5, 
    colaboradores: 15, 
    alunos: 100 
};
