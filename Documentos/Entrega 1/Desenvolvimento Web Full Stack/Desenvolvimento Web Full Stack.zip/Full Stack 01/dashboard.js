document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("totalEventos").textContent = eventos.length;
    document.getElementById("totalUsuarios").textContent = usuarios.total;

    const listaEventos = document.getElementById("listaEventos");
    eventos.forEach(evento => {
        let eventoItem = document.createElement("p");
        eventoItem.textContent = `${evento.nome} - ${evento.data} - R$${evento.preco}`;
        listaEventos.appendChild(eventoItem);
    });
});
